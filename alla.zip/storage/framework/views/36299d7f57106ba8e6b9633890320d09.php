<img src="https://lalodev.com/images/icon.png" width="50">
<?php /**PATH C:\Users\ikzax\Documents\GitHub\learning_hub\resources\views/components/application-logo.blade.php ENDPATH**/ ?>