<img src="https://lalodev.com/images/icon.png" width="50">
